#include <iostream>
#include "functie.h"
using namespace std;

void salut() {
    cout << "Aceasta este o funcție nouă pe branch!" << endl;
}