#ifndef FUNCTIE_H
#define FUNCTIE_H

void salut();

#endif