#include <iostream>

#include "functie.h"
using namespace std;

int main() {
    cout << "Lucrare de laborator 9 - GitHub" << endl;
    cout << "Autor: maynmayn" << endl;

    salut();
    return 0;
}

    return 0;
}

