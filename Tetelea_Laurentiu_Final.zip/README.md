# Proiect – Tetelea Laurențiu

Acest repository conține lucrările, laboratoarele și proiectele realizate în cadrul disciplinei **Management / Testare / Sisteme de Operare**.

## 📁 Structura proiectului

### **1. Laboratoare**
Conține lucrările practice și laboratoarele aferente orelor de curs.

### **2. Referate**
Include lucrări teoretice și referate pe diverse teme.

### **3. Testare Web**
Documente legate de analiza, scenarii, testare și validarea elementelor web.

### **4. Git**
Materiale despre utilizarea Git și versiuni.

### **5. Alte Documente**
Fișiere auxiliare, rapoarte sau documente temporare.

### **6. Proiecte**
Include proiecte suplimentare (ex. Todo-Tetelea).

## 👨‍💻 Autor
**Tetelea Laurențiu**
